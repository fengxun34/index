import pandas as pd
import sqlite3
import json
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer

def update_system():
    print("--- 🚀 開始更新 SQL 知識庫 ---")
    
    # 1. 讀取 CSV
    try:
        df = pd.read_csv("medical_sheet.csv")
    except Exception as e:
        print(f"❌ 找不到 medical_sheet.csv: {e}")
        return

    knowledge_data = []
    for _, row in df.iterrows():
        # 組合內容：讓搜尋「胸口」或「悶」都能命中
        full_content = f"部位：{row['body_part']}。症狀：{row['keywords']}。建議：{row['advice']}。警告：{row['warning']}"
        knowledge_data.append({
            "dept": row['department'],
            "content": full_content
        })

    # 2. 訓練向量模型 (使用 char_wb 處理中文非常有效)
    texts = [d['content'] for d in knowledge_data]
    vectorizer = TfidfVectorizer(ngram_range=(1, 3), analyzer='char_wb')
    vectors = vectorizer.fit_transform(texts)

    # 儲存模型供 app.py 使用
    with open("vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)

    # 3. 寫入 SQLite
    conn = sqlite3.connect("vector_store.db")
    cursor = conn.cursor()
    cursor.execute("DROP TABLE IF EXISTS medical_chunks")
    cursor.execute("""
        CREATE TABLE medical_chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            department TEXT,
            content TEXT,
            vector_json TEXT
        )
    """)

    for i, doc in enumerate(knowledge_data):
        vec_list = vectors[i].toarray()[0].tolist()
        cursor.execute(
            "INSERT INTO medical_chunks (department, content, vector_json) VALUES (?, ?, ?)",
            (doc['dept'], doc['content'], json.dumps(vec_list))
        )
    
    conn.commit()
    conn.close()
    print(f"✅ SQL 資料庫更新完成！共處理 {len(knowledge_data)} 筆資料。")

if __name__ == "__main__":
    update_system()