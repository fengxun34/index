import sqlite3
import json
import pickle
import numpy as np
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ===== 從資料庫加載資料 =====
def load_sql_data():
    try:
        with open("vectorizer.pkl", "rb") as f:
            vec = pickle.load(f)
        conn = sqlite3.connect("vector_store.db")
        cursor = conn.execute("SELECT department, content, vector_json FROM medical_chunks")
        rows = cursor.fetchall()
        conn.close()
        if not rows: return [], [], None, None
        depts = [r[0] for r in rows]
        conts = [r[1] for r in rows]
        matrix = np.array([json.loads(r[2]) for r in rows]).astype(np.float32)
        return depts, conts, vec, matrix
    except:
        return [], [], None, None

departments, contents, vectorizer, doc_matrix = load_sql_data()

class AnswerRequest(BaseModel):
    question: str

@app.post("/rag/answer")
def rag_answer(req: AnswerRequest):
    global departments, contents, vectorizer, doc_matrix
    if vectorizer is None:
        departments, contents, vectorizer, doc_matrix = load_sql_data()

    if vectorizer is None:
        return {"answer": "資料庫未就緒", "retrieved_chunks": []}

    query_vec = vectorizer.transform([req.question]).toarray().astype(np.float32)
    sims = cosine_similarity(query_vec, doc_matrix)[0]
    
    hits = []
    for i, s in enumerate(sims):
        if s > 0: # 只要有相關就顯示
            hits.append({
                "department": departments[i],
                "content": contents[i],
                "score": float(s)
            })
    
    hits = sorted(hits, key=lambda x: x['score'], reverse=True)[:3]

    if not hits:
        return {"answer": "尚未取得檢索結果。", "retrieved_chunks": []}

    return {
        "answer": f"建議掛【{hits[0]['department']}】",
        "retrieved_chunks": hits
    }